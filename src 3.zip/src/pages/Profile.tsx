// 🧠 Purpose: Create the Profile page to display the user's basic profile information pulled from Firestore.

import React from 'react';

const Profile: React.FC = () => {
  // Placeholder: Replace with user data from context or Firebase later
  const mockUser = {
    name: 'Anonymous',
    age: 'N/A',
    bio: 'This is intentionally minimal.',
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Your Profile</h1>
      <div className="space-y-2">
        <p><strong>Name:</strong> {mockUser.name}</p>
        <p><strong>Age:</strong> {mockUser.age}</p>
        <p><strong>Bio:</strong> {mockUser.bio}</p>
      </div>
    </div>
  );
};

export default Profile;