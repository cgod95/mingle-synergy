// 🧠 Purpose: Create the Matches page to display a list of matched users pulled from Firestore.

import React from 'react';
import BottomNav from '../components/BottomNav';
import ErrorBoundary from '../components/ErrorBoundary';

const Matches: React.FC = () => {
  const matches = [
    { id: '1', name: 'Alex' },
    { id: '2', name: 'Jordan' },
    { id: '3', name: 'Taylor' },
  ];

  return (
    <ErrorBoundary>
      <div className="pb-16 p-4">
        <h1 className="text-xl font-bold mb-4">Your Matches</h1>
        <ul className="space-y-2">
          {matches.map((match) => (
            <li key={match.id} className="border p-2 rounded">
              {match.name}
            </li>
          ))}
        </ul>
      </div>
      <BottomNav />
    </ErrorBoundary>
  );
};

export default Matches;