// 🧠 Purpose: Create the ProfileEdit page to allow users to update their profile information in Firestore.
// --- File: /src/pages/ProfileEdit.tsx ---
import React, { useState } from 'react';

const ProfileEdit: React.FC = () => {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [bio, setBio] = useState('');

  const handleSave = () => {
    console.log('Save:', { name, age, bio });
    // Wire up with Firebase later
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Edit Profile</h1>
      <div className="space-y-4">
        <input
          className="w-full p-2 border rounded"
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          className="w-full p-2 border rounded"
          type="text"
          placeholder="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}
        />
        <textarea
          className="w-full p-2 border rounded"
          placeholder="Minimal bio"
          value={bio}
          onChange={(e) => setBio(e.target.value)}
        />
        <button
          className="bg-black text-white px-4 py-2 rounded"
          onClick={handleSave}
        >
          Save
        </button>
      </div>
    </div>
  );
};

export default ProfileEdit;
