import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Heart, Users, User } from 'lucide-react';

const BottomNav: React.FC = () => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow z-50">
      <ul className="flex justify-around items-center h-14">
        <li>
          <NavLink
            to="/venues"
            className={({ isActive }) =>
              isActive ? 'text-blue-600' : 'text-gray-500'
            }
          >
            <Home className="w-6 h-6" />
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/liked-users"
            className={({ isActive }) =>
              isActive ? 'text-blue-600' : 'text-gray-500'
            }
          >
            <Heart className="w-6 h-6" />
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/matches"
            className={({ isActive }) =>
              isActive ? 'text-blue-600' : 'text-gray-500'
            }
          >
            <Users className="w-6 h-6" />
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/profile"
            className={({ isActive }) =>
              isActive ? 'text-blue-600' : 'text-gray-500'
            }
          >
            <User className="w-6 h-6" />
          </NavLink>
        </li>
      </ul>
    </nav>
  );
};

export default BottomNav;
