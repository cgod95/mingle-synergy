export const buttonVariants = {
    default: 'bg-coral-500 text-white',
    ghost: 'bg-transparent text-coral-500',
  };