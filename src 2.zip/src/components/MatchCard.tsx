// src/components/MatchCard.tsx
import React from 'react';

type Match = {
  id: string;
  name: string;
  age: number;
  bio: string;
  photoUrl: string;
};

interface MatchCardProps {
  match: Match;
}

const MatchCard: React.FC<MatchCardProps> = ({ match }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 flex items-center space-x-4">
      <img
        src={match.photoUrl}
        alt={match.name}
        className="w-16 h-16 rounded-full object-cover"
      />
      <div>
        <h2 className="text-lg font-semibold">{match.name}, {match.age}</h2>
        <p className="text-sm text-gray-600">{match.bio}</p>
      </div>
    </div>
  );
};

export default MatchCard;
