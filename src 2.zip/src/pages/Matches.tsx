// 🧠 Purpose: Create the Matches page to display a list of matched users pulled from Firestore.

import React, { useEffect, useState } from 'react';
import { auth, db } from '../firebase';
import { collection, doc, getDoc } from 'firebase/firestore';

type Match = {
  id: string;
  name: string;
  age: number;
  bio: string;
};

const Matches: React.FC = () => {
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMatches = async () => {
      const user = auth.currentUser;
      if (!user) return;

      const docRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data();
        const matchedUserIds = data.matches || [];

        const matchedUsersData = await Promise.all(
          matchedUserIds.map(async (id: string) => {
            const userDoc = await getDoc(doc(db, 'users', id));
            return userDoc.exists() ? { id, ...userDoc.data() } : null;
          })
        );

        setMatches(matchedUsersData.filter(Boolean) as Match[]);
      }

      setLoading(false);
    };

    fetchMatches();
  }, []);

  if (loading) return <p className="p-4">Loading matches...</p>;

  if (!matches.length) return <p className="p-4">No matches yet.</p>;

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Your Matches</h1>
      <ul className="space-y-4">
        {matches.map((match) => (
          <li key={match.id} className="border p-4 rounded">
            <p><strong>Name:</strong> {match.name}</p>
            <p><strong>Age:</strong> {match.age}</p>
            <p><strong>Bio:</strong> {match.bio}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Matches;