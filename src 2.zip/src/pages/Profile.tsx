// 🧠 Purpose: Create the Profile page to display the user's basic profile information pulled from Firestore.

import React, { useEffect, useState } from 'react';
import { auth, db } from '../firebase';
import { doc, getDoc } from 'firebase/firestore';

type ProfileData = {
  name: string;
  age: number;
  bio: string;
};

const Profile: React.FC = () => {
  const [profileData, setProfileData] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      const user = auth.currentUser;
      if (!user) return;

      const docRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setProfileData(docSnap.data() as ProfileData);
      }
      setLoading(false);
    };

    fetchProfile();
  }, []);

  if (loading) return <p className="p-4">Loading profile...</p>;

  if (!profileData) return <p className="p-4">No profile found.</p>;

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Your Profile</h1>
      <p><strong>Name:</strong> {profileData.name}</p>
      <p><strong>Age:</strong> {profileData.age}</p>
      <p><strong>Bio:</strong> {profileData.bio}</p>
    </div>
  );
};

export default Profile;