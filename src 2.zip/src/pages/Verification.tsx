// 🧠 Purpose: Create the Verification page to guide users through account verification.
// --- File: /src/pages/Verification.tsx ---
import React, { useState } from 'react';
import ErrorBoundary from '../components/ErrorBoundary';

const Verification: React.FC = () => {
  const [step, setStep] = useState<'start' | 'upload' | 'success'>('start');

  const handleStart = () => setStep('upload');
  const handleUpload = () => setStep('success');

  return (
    <ErrorBoundary>
      <div className="p-4 max-w-md mx-auto">
        <h1 className="text-xl font-bold mb-4">Verify Your Identity</h1>

        {step === 'start' && (
          <>
            <p className="mb-4">To keep our community safe, we ask users to verify their identity.</p>
            <button
              className="bg-blue-600 text-white py-2 px-4 rounded"
              onClick={handleStart}
            >
              Start Verification
            </button>
          </>
        )}

        {step === 'upload' && (
          <>
            <p className="mb-4">Upload a clear image of your ID or a selfie holding your ID.</p>
            <input type="file" className="mb-4" />
            <button
              className="bg-green-600 text-white py-2 px-4 rounded"
              onClick={handleUpload}
            >
              Submit
            </button>
          </>
        )}

        {step === 'success' && (
          <p className="text-green-600 font-semibold">Thank you! Your verification is pending review.</p>
        )}
      </div>
    </ErrorBoundary>
  );
};

export default Verification;
