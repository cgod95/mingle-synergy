// 🧠 Purpose: Create the ProfileEdit page to allow users to update their profile information in Firestore.
// --- File: /src/pages/ProfileEdit.tsx ---
import React, { useState, useEffect } from 'react';
import { auth, db } from '../firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

const ProfileEdit: React.FC = () => {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [bio, setBio] = useState('');
  const [status, setStatus] = useState('');

  useEffect(() => {
    const fetchProfile = async () => {
      const user = auth.currentUser;
      if (!user) return;

      const docRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        setName(data.name || '');
        setAge(data.age || '');
        setBio(data.bio || '');
      }
    };

    fetchProfile();
  }, []);

  const handleSave = async () => {
    const user = auth.currentUser;
    if (!user) return;

    try {
      await setDoc(doc(db, 'users', user.uid), {
        name,
        age,
        bio,
      });
      setStatus('Profile updated successfully.');
    } catch (err) {
      setStatus('Failed to update profile.');
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-xl font-bold mb-4">Edit Profile</h1>
      <input
        className="w-full border px-3 py-2 mb-2 rounded"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Name"
      />
      <input
        className="w-full border px-3 py-2 mb-2 rounded"
        value={age}
        onChange={(e) => setAge(e.target.value)}
        placeholder="Age"
        type="number"
      />
      <textarea
        className="w-full border px-3 py-2 mb-2 rounded"
        value={bio}
        onChange={(e) => setBio(e.target.value)}
        placeholder="Bio"
      />
      <button
        className="w-full bg-blue-600 text-white py-2 rounded"
        onClick={handleSave}
      >
        Save Changes
      </button>
      {status && <p className="mt-2 text-sm text-gray-700">{status}</p>}
    </div>
  );
};

export default ProfileEdit;
